# بناء APK من GitHub

1. أنشئ Repository جديدًا على GitHub.
2. ارفع جميع ملفات هذا المشروع إليه.
3. افتح تبويب **Actions**.
4. اختر **Build Android APK**.
5. اضغط **Run workflow** إذا لم يبدأ البناء تلقائيًا.
6. انتظر حتى يظهر التشغيل بعلامة نجاح.
7. افتح صفحة التشغيل الناجح، ثم قسم **Artifacts**.
8. حمّل **HalalScan-debug-apk**.
9. فك الضغط عن الملف، وستجد `app-debug.apk`.
10. أرسل APK إلى هاتف Android وثبته.

## تشغيل الذكاء الاصطناعي

يمكن وضع رابط الخادم في GitHub:
Repository → Settings → Secrets and variables → Actions → New repository secret

الاسم:
`API_BASE_URL`

القيمة:
رابط خادم FastAPI الخاص بالمشروع، مثل:
`https://your-server.example.com`

إذا لم تضع السر، سيُبنى التطبيق أيضًا، لكن زر التحليل لن يستطيع الاتصال بخادم الذكاء الاصطناعي حتى يتم ضبط الرابط.
