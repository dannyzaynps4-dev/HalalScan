# HalalScan Android 0.2.0

هذه نسخة أقرب للمنتج الحقيقي:

Android:
- CameraX
- ML Kit OCR
- ML Kit Barcode
- اتصال آمن بواجهة Backend

Backend:
- FastAPI
- Open Food Facts API v3 لتحديد المنتج بالباركود
- Gemini مع Google Search grounding لتحليل الأدلة وإرجاع المصادر
- مفتاح Gemini يبقى على الخادم ولا يوضع داخل APK

## تشغيل الخادم

cd backend
python -m venv .venv
فعّل البيئة
pip install -r requirements.txt
انسخ .env.example إلى .env وضع GEMINI_API_KEY
uvicorn main:app --host 0.0.0.0 --port 8000

ثم غيّر API_BASE_URL في app/build.gradle.kts إلى عنوان HTTPS للخادم.

مهم: Open Food Facts مصدر بيانات مساعد وليس شهادة حلال. الحكم النهائي في التطبيق يبقى محافظاً ويستخدم "غير محسوم" عندما تكون الأدلة غير كافية.


## APK سريع
يمكنك بناء APK من GitHub Actions باتباع `BUILD_APK_GITHUB.md`.
