import os, json, re
import httpx
from fastapi import FastAPI
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()
app = FastAPI(title="HalalScan API")
GEMINI_KEY = os.getenv("GEMINI_API_KEY", "")

class AnalyzeRequest(BaseModel):
    barcode: str = ""
    ocr_text: str = ""
    language: str = "ar"

async def off_product(barcode: str):
    if not barcode:
        return {}
    url = f"https://world.openfoodfacts.org/api/v3/product/{barcode}.json"
    headers = {"User-Agent": "HalalScan/0.2.0 (contact: replace-with-your-email)"}
    async with httpx.AsyncClient(timeout=12, follow_redirects=True) as c:
        r = await c.get(url, headers=headers)
        if r.status_code != 200:
            return {}
        data = r.json()
        p = data.get("product") or {}
        return {
            "name": p.get("product_name") or p.get("product_name_en") or "",
            "barcode": barcode,
            "ingredients": p.get("ingredients_text") or p.get("ingredients_text_en") or "",
            "brands": p.get("brands") or "",
            "labels": p.get("labels") or "",
            "countries": p.get("countries") or "",
            "url": f"https://world.openfoodfacts.org/product/{barcode}"
        }

def clean_json(text: str):
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text).strip()
        text = re.sub(r"```$", "", text).strip()
    try:
        return json.loads(text)
    except Exception:
        return {
            "status": "uncertain",
            "summary": text[:1200],
            "confidence": 25,
            "sources": []
        }

async def gemini_analyze(product, ocr):
    if not GEMINI_KEY:
        return {"status":"uncertain","summary":"لم يتم إعداد مفتاح الذكاء الاصطناعي بعد.","confidence":0,"sources":[]}

    prompt = f"""
أنت محرك تحليل لمنتجات غذائية من منظور الحلال. لا تفترض معلومات غير موجودة.
حلل المنتج اعتماداً على بياناته الحالية وابحث في الويب عن المنتج نفسه، الشركة المصنعة،
المكونات، مصدر المكونات الحساسة، وشهادة حلال إن وجدت. أعطِ نتيجة محافظة:
halal فقط إذا كانت الأدلة كافية ولا توجد مشكلة ظاهرة؛ not_halal إذا وُجد دليل واضح على
مكوّن غير حلال؛ uncertain إذا كان هناك نقص أو غموض مهم. لا تعتبر مجرد وجود E-number
دليلاً على التحريم دون معرفة المصدر.
أعد JSON فقط بهذا الشكل:
{{
 "status":"halal|not_halal|uncertain",
 "summary":"شرح عربي قصير جداً",
 "confidence":0,
 "sources":[{{"title":"اسم المصدر","url":"https://..."}}]
}}
بيانات قاعدة المنتج:
{json.dumps(product, ensure_ascii=False)}
النص المقروء من العبوة:
{ocr[:8000]}
"""
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"
    payload = {
        "contents":[{"parts":[{"text":prompt}]}],
        "tools":[{"google_search":{}}],
        "generationConfig":{"responseMimeType":"application/json"}
    }
    headers = {"x-goog-api-key": GEMINI_KEY, "Content-Type":"application/json"}
    async with httpx.AsyncClient(timeout=45) as c:
        r = await c.post(url, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()

    text = ""
    for cand in data.get("candidates", []):
        for part in cand.get("content", {}).get("parts", []):
            if "text" in part:
                text += part["text"]
    result = clean_json(text)

    # Preserve verifiable product source as a baseline source.
    if product.get("url"):
        result.setdefault("sources", [])
        if not any(s.get("url")==product["url"] for s in result["sources"]):
            result["sources"].insert(0, {"title":"Open Food Facts — بيانات المنتج","url":product["url"]})
    return result

@app.get("/health")
async def health():
    return {"ok": True}

@app.post("/analyze")
async def analyze(req: AnalyzeRequest):
    product = await off_product(req.barcode)
    if not product:
        product = {"name":"","barcode":req.barcode,"ingredients":""}
    result = await gemini_analyze(product, req.ocr_text)
    result["product"] = product
    return result
