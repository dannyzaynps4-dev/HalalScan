package com.halalscan.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import okhttp3.*
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var resultBox: LinearLayout
    private var analyzeNextFrame = false
    private val executor = Executors.newSingleThreadExecutor()
    private val client = OkHttpClient()

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startCamera() else status.text = "نحتاج إذن الكاميرا لفحص المنتج." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(248,250,249))
        }
        val title = TextView(this).apply {
            text = "حلال سكان\nHalalScan"; textSize = 28f
            setTextColor(Color.rgb(8,127,91)); gravity = Gravity.RIGHT
            setPadding(0,0,0,12)
        }
        preview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        status = TextView(this).apply {
            text = "وجّه الكاميرا إلى الباركود أو قائمة المكونات"
            textSize = 16f; gravity = Gravity.CENTER; setPadding(8,12,8,12)
        }
        val scan = Button(this).apply {
            text = "📷 التقط وحلّل"; setOnClickListener { captureAndAnalyze() }
        }
        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
        }
        root.addView(title); root.addView(preview); root.addView(status)
        root.addView(scan); root.addView(resultBox)
        setContentView(root)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUse = Preview.Builder().build().also { it.surfaceProvider = preview.surfaceProvider }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { imageProxy ->
                if (analyzeNextFrame) {
                    analyzeNextFrame = false
                    analyzeImage(imageProxy)
                } else imageProxy.close()
            }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUse, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureAndAnalyze() {
        status.text = "🔎 جارٍ قراءة المنتج..."
        analyzeNextFrame = true
    }

    private fun analyzeImage(imageProxy: ImageProxy) {
        val media = imageProxy.image ?: run { imageProxy.close(); return }
        val image = InputImage.fromMediaImage(media, imageProxy.imageInfo.rotationDegrees)
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val scanner = BarcodeScanning.getClient()

        recognizer.process(image).addOnSuccessListener { text ->
            scanner.process(image).addOnSuccessListener { barcodes ->
                val barcode = barcodes.firstOrNull()?.rawValue ?: ""
                val extracted = text.text.trim()
                runOnUiThread { sendToBackend(extracted, barcode) }
            }.addOnFailureListener {
                runOnUiThread { sendToBackend(text.text.trim(), "") }
            }.addOnCompleteListener { imageProxy.close() }
        }.addOnFailureListener {
            runOnUiThread { sendToBackend("", "") }
            imageProxy.close()
        }
    }

    private fun sendToBackend(ocr: String, barcode: String) {
        status.text = "🌐 نبحث عن المنتج ونحلل الأدلة..."
        val body = JSONObject().apply {
            put("barcode", barcode)
            put("ocr_text", ocr)
            put("language", "ar")
        }.toString().toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("${BuildConfig.API_BASE_URL}/analyze")
            .post(body).build()

        client.newCall(request).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { showError("تعذر الاتصال بالخادم. تأكد من إعداد API_BASE_URL.") }
            }
            override fun onResponse(call: Call, response: Response) {
                val raw = response.body?.string() ?: "{}"
                runOnUiThread {
                    if (response.isSuccessful) showApiResult(JSONObject(raw))
                    else showError("تعذر تحليل المنتج: ${response.code}")
                }
            }
        })
    }

    private fun showApiResult(obj: JSONObject) {
        resultBox.removeAllViews(); resultBox.visibility = View.VISIBLE
        val statusValue = obj.optString("status", "uncertain")
        val label = when(statusValue) {
            "halal" -> "🟢 حلال حسب الأدلة المتاحة"
            "not_halal" -> "🔴 غير حلال حسب الأدلة المتاحة"
            else -> "🟡 غير محسوم"
        }
        addText("نتيجة الفحص", 23f, Color.rgb(8,127,91))
        addText(label, 20f, Color.DKGRAY)
        addText(obj.optString("summary", "لا يوجد تفسير."), 16f, Color.DKGRAY)
        val product = obj.optJSONObject("product")
        if (product != null) {
            addText("\nالمنتج: ${product.optString("name","غير معروف")}", 15f, Color.DKGRAY)
            addText("الباركود: ${product.optString("barcode","غير معروف")}", 14f, Color.GRAY)
            addText("المكونات: ${product.optString("ingredients","غير متوفرة")}", 14f, Color.DKGRAY)
        }
        addText("\nدرجة الثقة: ${obj.optInt("confidence",0)}%", 14f, Color.GRAY)
        val sources = obj.optJSONArray("sources")
        if (sources != null && sources.length() > 0) {
            addText("\nالمصادر:", 17f, Color.rgb(8,127,91))
            for (i in 0 until sources.length()) {
                val s = sources.getJSONObject(i)
                addText("• ${s.optString("title","مصدر")} \n${s.optString("url","")}", 13f, Color.DKGRAY)
            }
        }
        val reset = Button(this).apply { text = "فحص منتج آخر"; setOnClickListener {
            resultBox.visibility = View.GONE
            status.text = "وجّه الكاميرا إلى الباركود أو قائمة المكونات"
        }}
        resultBox.addView(reset)
    }

    private fun addText(t: String, size: Float, color: Int) {
        resultBox.addView(TextView(this).apply {
            text = t; textSize = size; setTextColor(color); setPadding(0,8,0,8)
        })
    }

    private fun showError(message: String) {
        resultBox.removeAllViews(); resultBox.visibility = View.VISIBLE
        addText("حدث خطأ", 22f, Color.rgb(160,40,40))
        addText(message, 15f, Color.DKGRAY)
    }
}
